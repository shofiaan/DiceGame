package com.example.shutdice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
    private Button mulai, udah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        mulai = (Button) findViewById(R.id.go);
        mulai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                opentm();
            }
        });

        udah = (Button) findViewById(R.id.quit);
        udah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                qwt();
            }
        });

    }
    public void opentm(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void qwt(){
        finish();
    }
}
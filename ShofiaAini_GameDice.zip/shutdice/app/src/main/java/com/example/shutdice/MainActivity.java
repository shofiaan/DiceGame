package com.example.shutdice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    MediaPlayer player;
    Button b_player1_1, b_player1_2, b_player1_3, b_player1_4, b_player1_5, b_player1_6, b_player1_7, b_player1_8, b_player1_9;
    Button b_player2_1, b_player2_2, b_player2_3, b_player2_4, b_player2_5, b_player2_6, b_player2_7, b_player2_8, b_player2_9;


    List<Button> player1Buttons;
    List<Button> player2Buttons;

    Button b_player1_roll_1, b_player1_roll_2;
    Button b_player2_roll_1, b_player2_roll_2;
    Button reset;

    ImageView iv_dice1, iv_dice2;

    TextView tv_player1_points, tv_player2_points;
    TextView tv_status;

    int player1Points = 1+2+3+4+5+6+7+8+9;
    int player2Points = 1+2+3+4+5+6+7+8+9;
    int dice1, dice2, diceSum; //dice value and sum of both dice

    List<Integer> combinations; //all variable combination of digits for rolled end dice
    private Button btn_restart, btn_exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //music start
        player = MediaPlayer.create(this, R.raw.sound);
        player.start();
        player.setLooping(true);

        //restart
        btn_restart = findViewById(R.id.restart);
        btn_restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                player.stop();
                startActivity(getIntent());
            }
        });

        //exit
        btn_exit = findViewById(R.id.out);
        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.stop();
                finish();
            }
        });

        //define all elements on the screen
        b_player1_1 = findViewById(R.id.b_player1_1);
        b_player1_2 = findViewById(R.id.b_player1_2);
        b_player1_3 = findViewById(R.id.b_player1_3);
        b_player1_4 = findViewById(R.id.b_player1_4);
        b_player1_5 = findViewById(R.id.b_player1_5);
        b_player1_6 = findViewById(R.id.b_player1_6);
        b_player1_7 = findViewById(R.id.b_player1_7);
        b_player1_8 = findViewById(R.id.b_player1_8);
        b_player1_9 = findViewById(R.id.b_player1_9);

        b_player1_1.setTag("1");
        b_player1_2.setTag("2");
        b_player1_3.setTag("3");
        b_player1_4.setTag("4");
        b_player1_5.setTag("5");
        b_player1_6.setTag("6");
        b_player1_7.setTag("7");
        b_player1_8.setTag("8");
        b_player1_9.setTag("9");

        player1Buttons = new ArrayList<>();
        player1Buttons.add(b_player1_1);
        player1Buttons.add(b_player1_2);
        player1Buttons.add(b_player1_3);
        player1Buttons.add(b_player1_4);
        player1Buttons.add(b_player1_5);
        player1Buttons.add(b_player1_6);
        player1Buttons.add(b_player1_7);
        player1Buttons.add(b_player1_8);
        player1Buttons.add(b_player1_9);


        b_player2_1 = findViewById(R.id.b_player2_1);
        b_player2_2 = findViewById(R.id.b_player2_2);
        b_player2_3 = findViewById(R.id.b_player2_3);
        b_player2_4 = findViewById(R.id.b_player2_4);
        b_player2_5 = findViewById(R.id.b_player2_5);
        b_player2_6 = findViewById(R.id.b_player2_6);
        b_player2_7 = findViewById(R.id.b_player2_7);
        b_player2_8 = findViewById(R.id.b_player2_8);
        b_player2_9 = findViewById(R.id.b_player2_9);

        b_player2_1.setTag("1");
        b_player2_2.setTag("2");
        b_player2_3.setTag("3");
        b_player2_4.setTag("4");
        b_player2_5.setTag("5");
        b_player2_6.setTag("6");
        b_player2_7.setTag("7");
        b_player2_8.setTag("8");
        b_player2_9.setTag("9");

        player2Buttons = new ArrayList<>();
        player2Buttons.add(b_player2_1);
        player2Buttons.add(b_player2_2);
        player2Buttons.add(b_player2_3);
        player2Buttons.add(b_player2_4);
        player2Buttons.add(b_player2_5);
        player2Buttons.add(b_player2_6);
        player2Buttons.add(b_player2_7);
        player2Buttons.add(b_player2_8);
        player2Buttons.add(b_player2_9);

        b_player1_roll_1 = findViewById(R.id.b_player1_roll_1);
        b_player1_roll_2 = findViewById(R.id.b_player1_roll_2);

        b_player2_roll_1 = findViewById(R.id.b_player2_roll_1);
        b_player2_roll_2 = findViewById(R.id.b_player2_roll_2);

        iv_dice1 = findViewById(R.id.iv_dice1);
        iv_dice2 = findViewById(R.id.iv_dice2);

        tv_player1_points = findViewById(R.id.tv_player1_points);
        tv_player2_points = findViewById(R.id.tv_player2_points);
        tv_status = findViewById(R.id.tv_status);

        combinations = new ArrayList<>();

        //disable player1 buttons
        for(Button button: player1Buttons){
            button.setEnabled(false);
        }
        //disable button player2
        for(Button button: player2Buttons){
            button.setEnabled(false);
        }

        //disable roll buttons except player roll 2 button
        b_player1_roll_1.setEnabled(false);
        b_player2_roll_1.setEnabled(false);
        b_player2_roll_2.setEnabled(false);

        //add click listener
        for (Button button: player1Buttons){
            button.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    //remove the tile
                    v.setVisibility(View.INVISIBLE);

                    //dasable all tiles
                    for (Button button : player1Buttons){
                        button.setEnabled(false);
                    }
                    //remove the tile value from player points
                    diceSum = diceSum - Integer.parseInt(v.getTag().toString());
                    player1Points = player1Points - Integer.parseInt(v.getTag().toString());

                    //calculate remaining tiles
                    calculateTiles(diceSum, player1Buttons);

                    //check if player is finished
                    if(diceSum == 0){
                        iv_dice1.setVisibility(View.GONE);
                        iv_dice2.setVisibility(View.GONE);

                        //enable only one or both dice according to the rules
                        if(b_player1_7.getVisibility() == View.VISIBLE
                                || b_player1_8.getVisibility() == View.VISIBLE
                                || b_player1_9.getVisibility() == View.VISIBLE) {
                            b_player1_roll_1.setEnabled(false);
                            b_player1_roll_2.setEnabled(true);
                        } else {
                            b_player1_roll_1.setEnabled(true);
                            b_player1_roll_2.setEnabled(true);
                        }

                        //disable the tiles
                        for (Button button : player1Buttons){
                            button.setEnabled(false);
                        }
                    } else {
                        checkPlayer1End();
                    }
                }
            });
        }
        for (Button button: player2Buttons){
            button.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    //remove the tile
                    v.setVisibility(View.INVISIBLE);

                    //dasable all tiles
                    for (Button button : player2Buttons){
                        button.setEnabled(false);
                    }
                    //remove the tile value from player points
                    diceSum = diceSum - Integer.parseInt(v.getTag().toString());
                    player2Points = player2Points - Integer.parseInt(v.getTag().toString());

                    //calculate remaining tiles
                    calculateTiles(diceSum, player2Buttons);

                    //check if player is finished
                    if(diceSum == 0){
                        iv_dice1.setVisibility(View.GONE);
                        iv_dice2.setVisibility(View.GONE);

                        //enable only one or both dice according to the rules
                        if(b_player2_7.getVisibility() == View.VISIBLE
                                || b_player2_8.getVisibility() == View.VISIBLE
                                || b_player2_9.getVisibility() == View.VISIBLE) {
                            b_player2_roll_1.setEnabled(false);
                            b_player2_roll_2.setEnabled(true);
                        } else {
                            b_player2_roll_1.setEnabled(true);
                            b_player2_roll_2.setEnabled(true);
                        }

                        //disable the tiles
                        for (Button button : player2Buttons){
                            button.setEnabled(false);
                        }
                    } else {
                        checkPlayer2End();
                    }
                }
            });
        }

        //add roll buttons listeners
        b_player1_roll_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b_player1_roll_1.setEnabled(false);
                b_player1_roll_2.setEnabled(false);
                //show dice
                Random random = new Random();
                dice1 = random.nextInt(6)+1;
                diceSum = dice1;
                iv_dice1.setVisibility(View.VISIBLE);
                setDiceImages(dice1, iv_dice1);

                //animation
                Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                iv_dice1.startAnimation(rotate);
                //calculate the tiles
                calculateTiles(diceSum, player1Buttons);

                //check if the player is winner
                checkPlayer1End();
            }
        });
        b_player1_roll_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b_player1_roll_1.setEnabled(false);
                b_player1_roll_2.setEnabled(false);

                Random random = new Random();
                dice1 = random.nextInt(6)+1;
                dice2 = random.nextInt(6)+1;
                diceSum = dice1+dice2;
                iv_dice1.setVisibility(View.VISIBLE);
                iv_dice2.setVisibility(View.VISIBLE);
                setDiceImages(dice1, iv_dice1);
                setDiceImages(dice2, iv_dice2);

                //animation
                Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                iv_dice1.startAnimation(rotate);
                iv_dice2.startAnimation(rotate);

                //calculate the tiles
                calculateTiles(diceSum, player1Buttons);

                //check if the player is winner
                checkPlayer1End();
            }
        });

        //add roll pl2 buttons listeners
        b_player2_roll_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b_player2_roll_1.setEnabled(false);
                b_player2_roll_2.setEnabled(false);
                //show dice
                Random random = new Random();
                dice1 = random.nextInt(6)+1;
                diceSum = dice1;
                iv_dice1.setVisibility(View.VISIBLE);
                setDiceImages(dice1, iv_dice1);

                //animation
                Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                iv_dice1.startAnimation(rotate);


                //calculate the tiles
                calculateTiles(diceSum, player2Buttons);

                //check if the player is winner
                checkPlayer2End();
            }
        });
        b_player2_roll_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//19:39
                b_player2_roll_1.setEnabled(false);
                b_player2_roll_2.setEnabled(false);
                //show dice
                Random random = new Random();
                dice1 = random.nextInt(6)+1;
                dice2 = random.nextInt(6)+1;
                diceSum = dice1 + dice2;
                iv_dice1.setVisibility(View.VISIBLE);
                iv_dice2.setVisibility(View.VISIBLE);
                setDiceImages(dice1, iv_dice1);
                setDiceImages(dice2, iv_dice2);

                //animation
                Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                iv_dice1.startAnimation(rotate);
                iv_dice2.startAnimation(rotate);

                //calculate the tiles
                calculateTiles(diceSum, player2Buttons);

                //check if the player is winner
                checkPlayer2End();
            }
        });


    }
    //set dice image when rolled
    private void setDiceImages(int number, ImageView image){
        switch (number){
            case 1:
                image.setImageResource(R.drawable.dc1);
                break;
            case 2:
                image.setImageResource(R.drawable.dc2);
                break;
            case 3:
                image.setImageResource(R.drawable.dc3);
                break;
            case 4:
                image.setImageResource(R.drawable.dc4);
                break;
            case 5:
                image.setImageResource(R.drawable.dc5);
                break;
            case 6:
                image.setImageResource(R.drawable.dc6);
                break;
        }
    }

    //show available numbers for the rolled dice
    private void showDigits(ArrayList<Integer> numbers, int target, ArrayList<Integer> partial) {
        int s=0;

        for(int x:partial){
            s+=x;
        }
        if(s==target){
            for(int num:partial){
                if(!combinations.contains(num)){
                    combinations.add(num);
                }
            }
        }

        if(s>=target){
            return;
        }

        for(int i=0; i<numbers.size(); i++){
            ArrayList<Integer> remaining = new ArrayList<>();
            int n = numbers.get(i);
            for(int j=i+1; j<numbers.size(); j++){
                remaining.add(numbers.get(j));
            }
            ArrayList<Integer> partial_rec = new ArrayList<>(partial);
            partial_rec.add(n);
            showDigits(remaining, target, partial_rec);
        }
    }

    private void showNumbers(ArrayList<Integer> numbers, int target){
        combinations.clear();
        showDigits(numbers, target, new ArrayList<Integer>());
    }

    private void calculateTiles(int number, List<Button> buttons){
        //save variable files
        ArrayList<Integer>numbers = new ArrayList<>();
        for(Button button:buttons){
            if (button.getVisibility() == View.VISIBLE){
                numbers.add(Integer.parseInt(button.getTag().toString()));
            }
        }

        //calculate
        showNumbers(numbers, number);

        //enable the variable tiles
        for (int num:combinations){
            buttons.get(num - 1).setEnabled(true);
        }
    }

    //check if player 1 is over
    private void checkPlayer1End(){
        //check id there is availabel tiles
        boolean playerTurn = true;
        for(Button button:player1Buttons){
            if(button.isEnabled()){
                playerTurn = false;
            }
        }
         //switch turn if no tiles
        if(playerTurn){
            tv_player1_points.setText(""+player1Points);
            tv_status.setTextSize(26);
            tv_status.setText("Player 2 roll the dice!");
            b_player2_roll_2.setEnabled(true);
        }

        //chck if player1 directly wins the game
        boolean checkWin = true;
        for(Button button:player1Buttons){
            if(button.getVisibility() == View.VISIBLE){
                checkWin = false;
            }
        }

        if (checkWin){
            tv_status.setTextSize(40);
            tv_status.setText("PLAYER 1 WINS..!!");
        }
    }

    //check id player2 is over
    private void checkPlayer2End(){
        //check id there is availabel tiles
        boolean playerTurn = true;
        for(Button button:player2Buttons){
            if(button.isEnabled()){
                playerTurn = false;
            }
        }
        //end if no tiles
        if(playerTurn){
            tv_player2_points.setText(""+player2Points);
            if(player1Points<player2Points){
                tv_status.setTextSize(40);
                tv_status.setText("PLAYER 1 WINS..!!");
            } else if(player2Points < player1Points){
                tv_status.setTextSize(40);
                tv_status.setText("PLAYER 2 WINS..!!");
            } else {
                tv_status.setTextSize(40);
                tv_status.setText("DRAW");
            }
        }

        //chck if player1 directly wins the game
        boolean checkWin = true;
        for(Button button:player2Buttons){
            if(button.getVisibility() == View.VISIBLE){
                checkWin = false;
            }
        }

        if (checkWin){
            tv_status.setTextSize(40);
            tv_status.setText("PLAYER 2 WINS..!!");
        }
    }//41:08
}